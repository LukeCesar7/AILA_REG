import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Motor AILA 3.2 - Refatorado para Navegação Dinâmica de Especialidades
 */
export const sendMessageToAILA = async (
  message: string, 
  history: any[],
  relevantContext?: string,
  legalArea: string = 'Direito Geral'
) => {
  const model = 'gemini-3-pro-preview';
  
  const areaInstructions: Record<string, string> = {
    'Direito Geral': 'Atue como Jurista Generalista. Integre fontes multidisciplinares e forneça uma visão holística do ordenamento brasileiro.',
    'Civil': 'Atue como Especialista em Direito Civil e Processo Civil. Priorize o CC/2002, o CPC/2015 e jurisprudência do STJ.',
    'Penal': 'Atue como Especialista em Direito Penal e Processo Penal. Priorize o CP, o CPP, garantias constitucionais e o sistema acusatório.',
    'Trabalhista': 'Atue como Especialista em Direito do Trabalho. Priorize a CLT e a Reforma de 2017.',
    'Tributário': 'Atue como Especialista em Direito Tributário. Foque no CTN e ritos de execução fiscal.',
    'Previdenciário': 'Atue como Especialista em Direito Previdenciário. Priorize a Lei 8.213/91 e o custeio da seguridade.',
    'Administrativo': 'Atue como Especialista em Direito Administrativo. Priorize a Lei 9.784/99 e princípios da Administração.',
    'Consumidor': 'Atue como Especialista em Direito do Consumidor. Priorize o CDC e a responsabilidade objetiva.'
  };
  
  const systemInstruction = `Você é AILA (Assistente de Inteligência Legal Avançada).
  
  COMANDO DE NAVEGAÇÃO: O usuário selecionou a especialidade [${legalArea}].
  DIRETRIZ TÉCNICA: ${areaInstructions[legalArea] || areaInstructions['Direito Geral']}

  INSTRUÇÃO DE INTEGRIDADE:
  O usuário forneceu documentos integrais (CPP, CPC, etc.) no sistema. Ao fundamentar, use o texto exato dos artigos citados.

  CONTEXTO DOCUMENTAL:
  ${relevantContext ? `Utilize estes anexos para o parecer:\n${relevantContext}` : 'Nenhum anexo adicional fornecido nesta rodada.'}

  ESTILO DE RESPOSTA:
  1. Formato de Parecer Forense (Relatório, Fundamentação, Conclusão).
  2. Negrito em artigos e prazos.
  3. Tom austero, preciso e técnico.
  4. Reconheça mudanças de especialidade imediatamente na resposta.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [...history, { role: 'user', parts: [{ text: message }] }],
      config: {
        systemInstruction,
        temperature: 0.1,
      }
    });
    
    return response.text;
  } catch (error) {
    console.error("AILA Core Error:", error);
    throw error;
  }
};