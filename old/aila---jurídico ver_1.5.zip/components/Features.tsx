
import React from 'react';

const featureList = [
  {
    icon: 'balance',
    title: 'Análise de Processos',
    desc: 'Analise milhares de documentos em segundos com precisão cirúrgica e identifique riscos e oportunidades.'
  },
  {
    icon: 'description',
    title: 'Redação de Petições',
    desc: 'Gere rascunhos de alta qualidade baseados na jurisprudência atualizada dos tribunais superiores.'
  },
  {
    icon: 'travel_explore',
    title: 'Pesquisa Avançada',
    desc: 'Encontre precedentes e decisões relevantes instantaneamente usando linguagem natural.'
  },
  {
    icon: 'database',
    title: 'Base de Conhecimento RAG',
    desc: 'IA com RAG estruturado baseado em PDFs e artigos oficiais da Lei Brasileira para respostas atualizadas.'
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-24 bg-background-light dark:bg-background-dark">
      <div className="max-w-[1440px] mx-auto px-6">
        <div className="mb-16">
          <h2 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white mb-6">
            Excelência impulsionada por IA
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl leading-relaxed">
            Nossa plataforma combina tecnologia de ponta com conhecimento jurídico especializado para oferecer as ferramentas que você precisa no dia a dia.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {featureList.map((f, i) => (
            <div key={i} className="group bg-white dark:bg-background-card border border-slate-200 dark:border-[#323f67] p-8 rounded-2xl transition-all hover:border-primary/50 hover:shadow-2xl hover:shadow-primary/5">
              <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-all">
                <span className="material-symbols-outlined">{f.icon}</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">{f.title}</h3>
              <p className="text-slate-600 dark:text-[#92a0c9] leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
