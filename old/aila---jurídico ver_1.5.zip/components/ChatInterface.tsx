
import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { sendMessageToAILA } from '../services/gemini';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatInterfaceProps {
  onClose: () => void;
  clearTrigger?: number;
}

const STORAGE_KEY = 'aila_chat_history';

const ChatInterface: React.FC<ChatInterfaceProps> = ({ onClose, clearTrigger }) => {
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse chat history", e);
      }
    }
    return [{ role: 'assistant', content: '### Saudação Institucional\n\nOlá! Sou **AILA**, sua assistente jurídica. Como posso auxiliar em sua prática advocatícia ou pesquisa acadêmica hoje? Estou pronta para analisar **jurisprudência**, redigir **petições** ou avaliar **estratégias processuais**.' }];
  });
  
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    if (scrollRef.current) {
      // Pequeno delay para garantir que o DOM renderizou o novo conteúdo
      setTimeout(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTo({
            top: scrollRef.current.scrollHeight,
            behavior: 'smooth'
          });
        }
      }, 100);
    }
  }, [messages, isLoading]);

  // Handle external clear trigger
  useEffect(() => {
    if (clearTrigger && clearTrigger > 0) {
      if (window.confirm('Deseja realmente eliminar todo o histórico de consultas?')) {
        const defaultMsg: Message[] = [{ role: 'assistant', content: 'Olá! Sou **AILA**, sua assistente jurídica. Como posso ajudar na sua prática advocatícia hoje?' }];
        setMessages(defaultMsg);
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, [clearTrigger]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    const newMessages = [...messages, { role: 'user', content: userMsg } as Message];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const history = newMessages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      const response = await sendMessageToAILA(userMsg, history);
      setMessages(prev => [...prev, { role: 'assistant', content: response || 'Ocorreu uma falha na geração do parecer.' }]);
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: '### Erro de Conexão\n\nHouve um erro na comunicação com os servidores. Por favor, verifique sua conexão com a rede.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] mt-20 bg-[#0b0f1a] text-white relative overflow-hidden">
      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-grow overflow-y-auto p-4 md:p-8 space-y-12"
      >
        {/* Padding inferior reduzido para pb-44 (~176px) para ficar logo abaixo da caixa de perguntas */}
        <div className="max-w-5xl mx-auto w-full space-y-12 pb-44">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`relative ${
                m.role === 'user' 
                  ? 'max-w-[70%] p-5 bg-primary/90 backdrop-blur-sm text-white rounded-2xl rounded-tr-none shadow-xl border border-white/10' 
                  : 'w-full p-8 md:p-14 bg-[#1c243a] border border-[#2d3855] rounded-xl shadow-2xl font-serif legal-content'
              }`}>
                {m.role === 'assistant' && (
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#c59d5f] to-transparent opacity-60 rounded-t-xl"></div>
                )}
                
                {m.role === 'assistant' ? (
                  <div className="text-[1.2rem] leading-[1.8] text-slate-200">
                     <div className="flex items-center justify-between mb-8 border-b border-[#2d3855]/50 pb-4">
                        <span className="text-[10px] uppercase tracking-[0.2em] font-sans text-[#c59d5f] font-bold">Documento Eletrônico Certificado</span>
                        <span className="text-[10px] uppercase tracking-[0.2em] font-sans text-slate-500">{new Date().toLocaleDateString('pt-BR')} | {new Date().toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}</span>
                     </div>
                     <ReactMarkdown>{m.content}</ReactMarkdown>
                  </div>
                ) : (
                  <p className="text-base font-sans leading-relaxed">{m.content}</p>
                )}
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-[#1c243a] border border-[#2d3855] p-6 rounded-xl flex items-center gap-4 shadow-xl">
                <span className="text-xs font-sans text-[#c59d5f] animate-pulse font-bold tracking-widest uppercase">Processando Parecer Técnico...</span>
                <div className="flex gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#c59d5f] animate-bounce"></span>
                  <span className="w-2 h-2 rounded-full bg-[#c59d5f] animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-2 h-2 rounded-full bg-[#c59d5f] animate-bounce [animation-delay:0.4s]"></span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Floating Centered Input Area */}
      <div className="absolute bottom-0 left-0 right-0 z-10">
        {/* Sombra (gradiente) reduzida para apenas h-4 para ficar encostada na caixa */}
        <div className="h-4 bg-gradient-to-t from-[#0b0f1a] to-transparent pointer-events-none"></div>
        <div className="bg-[#0b0f1a] pb-6 px-4 md:px-0">
          <div className="max-w-3xl mx-auto">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-primary/30 to-[#c59d5f]/30 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-[#192033]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-2 flex items-end gap-2">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Apresente os fatos para fundamentação jurídica..."
                  className="flex-grow bg-transparent border-none rounded-xl px-4 py-3 focus:ring-0 transition-all resize-none min-h-[50px] max-h-[200px] text-sm font-sans text-white placeholder:text-slate-500"
                  rows={1}
                />
                <button 
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="p-3 bg-primary hover:bg-blue-600 disabled:opacity-20 disabled:grayscale rounded-xl text-white transition-all shadow-lg flex-shrink-0"
                >
                  <span className="material-symbols-outlined text-2xl">send</span>
                </button>
              </div>
            </div>
            <div className="flex justify-center gap-4 mt-3 text-[8px] uppercase tracking-[0.2em] text-slate-500 font-bold bg-[#0b0f1a]/80 py-1.5 px-6 rounded-full w-max mx-auto border border-white/5 backdrop-blur-sm">
              <span>AILA 3.1 Pro Engine</span>
              <span className="text-slate-700">|</span>
              <span>Segurança Criptográfica</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
