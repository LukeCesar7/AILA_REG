
import React from 'react';

interface HeroProps {
  onStartChat: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStartChat }) => {
  return (
    <section className="min-h-screen flex flex-col lg:flex-row pt-20">
      {/* Left side: Dark Visual */}
      <div className="w-full lg:w-1/2 bg-background-dark flex flex-col justify-center items-center px-8 lg:px-20 py-20 relative overflow-hidden border-r border-[#232c48]">
        <div className="absolute inset-0 ai-orb-glow"></div>
        <div className="relative z-10 w-full max-w-lg">
          <div className="mb-12 relative flex justify-center lg:justify-start">
            <div className="w-64 h-64 mx-auto lg:mx-0 rounded-full bg-gradient-to-tr from-primary via-indigo-500 to-cyan-400 blur-2xl opacity-20 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
            <div className="w-48 h-48 rounded-full border border-primary/30 flex items-center justify-center relative">
              <div className="w-40 h-40 rounded-full border border-primary/50 flex items-center justify-center">
                <div className="w-32 h-32 rounded-full bg-gradient-to-b from-primary to-indigo-900 shadow-[0_0_50px_rgba(19,73,236,0.5)] flex items-center justify-center">
                  <span className="material-symbols-outlined text-white text-5xl opacity-80">gavel</span>
                </div>
              </div>
              <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-[spin_10s_linear_infinite]"></div>
            </div>
          </div>
          <h1 className="text-white text-5xl md:text-7xl font-black leading-[1.1] tracking-tight mb-6 text-center lg:text-left">
            Sua IA <br/><span className="text-primary">Jurídica</span> Especialista
          </h1>
          <p className="text-slate-400 text-lg md:text-xl font-light max-w-md leading-relaxed text-center lg:text-left mx-auto lg:mx-0">
            Aumente a precisão e a velocidade de suas pesquisas jurídicas com a inteligência artificial mais avançada do mercado brasileiro.
          </p>
        </div>
      </div>

      {/* Right side: Light Interactive */}
      <div className="w-full lg:w-1/2 bg-white dark:bg-background-light flex flex-col justify-center px-8 lg:px-20 py-20">
        <div className="w-full max-w-lg mx-auto lg:mx-0">
          <div className="mb-10">
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest mb-4">
              Novo: Gemmini Pro e História Jurídico 2025.2
            </span>
            <h3 className="text-slate-900 text-3xl font-bold mb-4">Comece agora a transformar sua prática jurídica.</h3>
            <p className="text-slate-600">
              Prepare rascunhos, analise jurisprudência e gerencie prazos com um assistente que entende as leis brasileiras profundamente.
            </p>
          </div>
          
          <div className="flex flex-col gap-4 mb-12">
            <button 
              onClick={onStartChat}
              className="w-full bg-primary hover:bg-blue-700 text-white h-14 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-xl shadow-primary/20 cursor-pointer active:scale-95"
            >
              <span className="material-symbols-outlined">chat_bubble</span>
              Acessar Chat da AILA
            </button>
          </div>

          <div className="grid grid-cols-2 gap-6 pt-10 border-t border-slate-100 dark:border-slate-200">
            <div className="flex flex-col">
              <span className="text-3xl font-bold text-slate-900">98%</span>
              <span className="text-sm text-slate-500 font-medium">Precisão Jurídica</span>
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-bold text-slate-900">10x</span>
              <span className="text-sm text-slate-500 font-medium">Mais Rápido</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
