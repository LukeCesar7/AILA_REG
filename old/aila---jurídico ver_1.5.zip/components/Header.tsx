
import React from 'react';

interface HeaderProps {
  isChatActive?: boolean;
  onCloseChat?: () => void;
  onClearChat?: () => void;
}

const Header: React.FC<HeaderProps> = ({ isChatActive, onCloseChat, onClearChat }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-nav border-b border-[#232c48]/50">
      <div className="max-w-[1440px] mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => !isChatActive && window.location.reload()}>
          <div className="text-primary">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path d="M42.1739 20.1739L27.8261 5.82609C29.1366 7.13663 28.3989 10.1876 26.2002 13.7654C24.8538 15.9564 22.9595 18.3449 20.6522 20.6522C18.3449 22.9595 15.9564 24.8538 13.7654 26.2002C10.1876 28.3989 7.13663 29.1366 5.82609 27.8261L20.1739 42.1739C21.4845 43.4845 24.5355 42.7467 28.1133 40.548C30.3042 39.2016 32.6927 37.3073 35 35C37.3073 32.6927 39.2016 30.3042 40.548 28.1133C42.7467 24.5355 43.4845 21.4845 42.1739 20.1739Z" fill="currentColor"></path>
            </svg>
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tighter text-white leading-none">AILA</h2>
            {isChatActive && (
              <p className="text-[10px] text-green-500 font-bold tracking-widest mt-1 animate-pulse">
                SISTEMA JURÍDICO ATIVO
              </p>
            )}
          </div>
        </div>
        
        {isChatActive ? (
          <div className="flex items-center gap-4">
            <button 
              onClick={onClearChat}
              title="Limpar Conversa"
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-all border border-white/10"
            >
              <span className="material-symbols-outlined text-xl">delete_sweep</span>
              <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Limpar</span>
            </button>
            <button 
              onClick={onCloseChat}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/20 hover:bg-primary text-primary hover:text-white transition-all border border-primary/30"
            >
              <span className="material-symbols-outlined text-xl">close</span>
              <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Sair</span>
            </button>
          </div>
        ) : (
          <button className="bg-primary/10 border border-primary/30 text-primary px-6 py-2 rounded-full font-bold hover:bg-primary hover:text-white transition-all">
            Entrar
          </button>
        )}
      </div>
    </nav>
  );
};

export default Header;
