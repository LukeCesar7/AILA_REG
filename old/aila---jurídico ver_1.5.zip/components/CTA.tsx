
import React from 'react';

const CTA: React.FC = () => {
  return (
    <section className="py-24 bg-background-light dark:bg-background-dark relative overflow-hidden border-t border-[#232c48]">
      <div className="max-w-[1000px] mx-auto px-6 relative z-10 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-widest mb-8">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
          </span>
          Pronto para começar
        </div>
        <h2 className="text-4xl md:text-6xl font-black text-slate-900 dark:text-white mb-8 tracking-tight">
          Eleve o patamar da sua <br/><span className="text-primary">advocacia hoje.</span>
        </h2>
        <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          Junte-se a centenas de advogados que já estão economizando horas de trabalho semanal com a AILA.
        </p>
        <button className="bg-primary hover:bg-blue-700 text-white px-10 py-4 rounded-xl font-bold text-xl transition-all shadow-xl shadow-primary/30">
          Começar Teste Grátis
        </button>
      </div>
      
      {/* Background Decor */}
      <div className="absolute -bottom-48 -left-48 w-96 h-96 bg-primary/10 blur-[120px] rounded-full"></div>
      <div className="absolute -top-48 -right-48 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full"></div>
    </section>
  );
};

export default CTA;
