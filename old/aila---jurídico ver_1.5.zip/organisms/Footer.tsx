
import React from 'react';
import { Logo } from '../atoms/Logo';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-background-dark py-12 border-t border-white/5">
      <div className="max-w-[1440px] mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            <Logo size="size-8" />
            <span className="text-white font-black tracking-tighter text-2xl">AILA</span>
          </div>
          <div className="flex gap-8 text-slate-400 text-sm">
            <a className="hover:text-white transition-colors" href="#">Termos</a>
            <a className="hover:text-white transition-colors" href="#">Privacidade</a>
            <a className="hover:text-white transition-colors" href="#">Contato</a>
          </div>
          <div className="text-slate-500 text-sm">
            © 2024 AILA Technologies. Todos os direitos reservados.
          </div>
        </div>
      </div>
    </footer>
  );
};
