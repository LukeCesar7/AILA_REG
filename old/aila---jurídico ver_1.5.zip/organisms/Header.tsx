import React from 'react';
import { Logo } from '../atoms/Logo';

interface HeaderProps {
  isChatActive?: boolean;
  onCloseChat?: () => void;
  onClearChat?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ isChatActive, onCloseChat, onClearChat }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] h-14 flex items-center px-10 justify-between select-none bg-black/10 backdrop-blur-md border-b border-white/5">
      <div className="flex items-center gap-6">
        <div className="flex items-center cursor-default group gap-3">
          <Logo size="size-6 text-white" />
          <div className="h-4 w-[1px] bg-white/20"></div>
          <span className="font-serif italic text-xl text-white tracking-tight">Aila</span>
          <span className="font-sans font-900 text-[9px] uppercase tracking-[0.3em] text-white/40 pt-1">Direito Brasileiro</span>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        {isChatActive ? (
          <div className="glass-vibrancy rounded-full px-2 py-1 flex gap-1 shadow-vibrancy border-white/60">
            <button 
              onClick={onClearChat}
              className="text-[10px] font-black uppercase tracking-wider text-slate-600 hover:text-red-600 px-4 py-1.5 rounded-full transition-all"
            >
              Limpar Histórico
            </button>
            <button 
              onClick={onCloseChat}
              className="text-[10px] font-black uppercase tracking-wider text-white bg-slate-900 hover:bg-black px-5 py-1.5 rounded-full transition-all shadow-lg"
            >
              Encerrar Sessão
            </button>
          </div>
        ) : (
          <div className="text-[10px] font-bold text-white/60 uppercase tracking-[0.2em] flex items-center gap-3">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_12px_rgba(74,222,128,0.6)]"></span>
            Sistema On-line
          </div>
        )}
      </div>
    </nav>
  );
};