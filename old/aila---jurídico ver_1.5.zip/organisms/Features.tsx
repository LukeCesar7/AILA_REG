
import React from 'react';

const featureList = [
  {
    icon: 'balance',
    title: 'Análise de Processos',
    desc: 'Escaneamento profundo de documentos com identificação de riscos processuais imediata.'
  },
  {
    icon: 'edit_document',
    title: 'Minutas Forenses',
    desc: 'Redação de alta fidelidade técnica seguindo os manuais de redação forense do TJSP.'
  },
  {
    icon: 'travel_explore',
    title: 'Jurisprudência Dinâmica',
    desc: 'Conexão com os principais precedentes dos Tribunais Superiores em tempo real.'
  },
  {
    icon: 'verified_user',
    title: 'Segurança Institucional',
    desc: 'Privacidade total de dados acadêmicos e processuais com criptografia militar.'
  }
];

export const Features: React.FC = () => {
  return (
    <section className="py-32 px-10 relative">
      <div className="max-w-[1440px] mx-auto">
        <div className="mb-24 animate-reveal">
          <h2 className="text-5xl md:text-6xl font-sans font-800 text-white mb-8 tracking-tighter drop-shadow-lg">
            Poder computacional.<br/>Precisão jurídica.
          </h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
          {featureList.map((f, i) => (
            <div key={i} className="group glass-vibrancy p-10 rounded-ios-lg shadow-vibrancy hover:bg-white transition-all animate-reveal border-white/80" style={{animationDelay: `${i * 0.1}s`}}>
              <div className="w-14 h-14 rounded-2xl bg-white shadow-md flex items-center justify-center mb-8 text-sequoia-blue group-hover:scale-110 transition-transform border border-black/5">
                <span className="material-symbols-outlined text-[32px]">{f.icon}</span>
              </div>
              <h3 className="text-xl font-900 text-slate-950 mb-4 tracking-tight">{f.title}</h3>
              <p className="text-slate-800 leading-relaxed font-bold text-sm opacity-80">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
